package com.taodigital.productservice.enums;

public enum Status {
	ACTIVE, DELETE, APPROVAL_QUEUE
}
