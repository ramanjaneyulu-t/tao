package com.taodigital.productservice.dto;

import lombok.Data;

@Data
public class ErrorResponse {
	private String message;
}
